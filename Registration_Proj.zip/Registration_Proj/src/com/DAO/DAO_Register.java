package com.DAO;

import com.Pojo.UserPOJO;

public interface DAO_Register {
 public boolean insert(UserPOJO user);
 boolean validate();
}
